Carpetas ejercicio3, ejercicio4 y ejercicio5: contienen las trazas y fotos realizadas para su respectivo ejercicio.

Carpeta ficherosConfiguracion: contiene los ficheros de configuración accefile y regexroute del servidor yate.

Foto errorUAM: foto de la traza al intentar registrarse con una cuenta linphone desde la UAM.

memoria.pdf: memoria de la práctica.
